import UserSignUp from '../../support/page-objects/end-to-end/User_SignUp'

context ('Account Creation', () => {

    const userSignUp = new UserSignUp();

    describe(`Pre-condition:`, { defaultCommandTimeout: 10000 }, () => {

        it(`User sign up`, () => {
            cy.visitPage('CMP');
            userSignUp.navigateToSignUp();
            userSignUp.newUserSignUp();
        })
    })
}) 