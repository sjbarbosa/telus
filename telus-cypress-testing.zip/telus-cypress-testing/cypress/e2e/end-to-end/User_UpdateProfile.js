import UserProfile from '../../support/page-objects/end-to-end/User_Profile'

context ('Update Account', () => {
    const userProfile = new UserProfile();

    describe(`Instructions:`, { defaultCommandTimeout: 10000 }, () => {

        it(`Update contact Info and Location`, () => {
            // Access https://www.telusinternational.ai/cmp again and log in using the credentials
            cy.visitPage('CMP');
            cy.login("USERCREDENTIAL1");

            // Click on the profile icon on top right of the screen.
            // Click on the “My profile” menu link. You should land on https://www.telusinternational.ai/cmp/contributor/userprofile/basic-info page.
            userProfile.navigateToMyProfile();
            cy.url(Cypress.env("TelusBasicInfo"));

            // Edit the Contact Info and the Location.
            userProfile.navigateToContactInfo();
            userProfile.updateContactInfo();
            userProfile.navigateToLocation();
            userProfile.updateLocation();

            // Click on the Languages left menu link. You should land on https://www.telusinternational.ai/cmp/contributor/userprofile/languages page.
            userProfile.navigateToLanguages();
            cy.url(Cypress.env("TelusLanguages"));
            
            // Add Primary and Other Languages.
            userProfile.updatePrimaryLanguage();
            userProfile.addOtherLanguage();

            // Repeat step 2 and click the Sign Out button.
            cy.logout();
        })
    })
}) 