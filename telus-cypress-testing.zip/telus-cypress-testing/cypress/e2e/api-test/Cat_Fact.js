import CAT_FACT from "../../support/page-objects/end-to-end/api-endpoints/CatFact_API";

describe(`Automation - API`, () => {
    it(`Validate API`, () => {
        cy.request(CAT_FACT.Fact).as('request');
        cy.get('@request').then(res => {
            expect(res.status).to.eq(200)
        });
        cy.request({
            method: 'POST',
            url: CAT_FACT.Fact,
            body: {
              fact: 'Fact About Cats',
              length: '15',
            },
        }).as('post')
    })
})