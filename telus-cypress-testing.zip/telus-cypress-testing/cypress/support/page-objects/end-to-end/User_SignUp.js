class UserSignUp{
    signUpButton = '//a[contains(text(),"Sign up")]';
    emailField = '//span[contains(text(),"Email")]/preceding-sibling::input';
    firstNameField = '//span[contains(text(),"First name")]/preceding-sibling::input';
    lastNameField = '//span[contains(text(),"Last name")]/preceding-sibling::input';
    servicesAgreementCheckbox = '.done-icon';
    csaAgreeButton = '.second-button-sla > .sui-rounded';
    continueButton = '.sc-eCApnc > .sui-rounded';

    el = {
        signUpButton: () => cy.xpath(this.signUpButton, {timeout: 10000}),
        emailField: () => cy.xpath(this.emailField, {timeout: 10000}),
        firstNameField: () => cy.xpath(this.firstNameField, {timeout: 10000}),
        lastNameField: () => cy.xpath(this.lastNameField, {timeout: 10000}),
        servicesAgreementCheckbox: () => cy.get(this.servicesAgreementCheckbox, {timeout: 10000}),
        csaAgreeButton: () => cy.get(this.csaAgreeButton, {timeout: 10000}),
        continueButton: () => cy.get(this.continueButton, {timeout: 10000}),
    }

    navigateToSignUp() {
        this.el.signUpButton().click({timeout: 10000});
    }

    newUserSignUp() {
        // Enter [Email]
        const generate = () => Cypress._.random(0, 1e6)
        const id = generate()
        const email = `user${id}@mailinator.com`
        this.el.emailField().type(email);

        function generateNames() {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        
            for (var i = 0; i < 10; i++)
                text += possible.charAt(Math.floor(Math.random() * possible.length));
                return text;
        }
        // Enter [First Name]
        this.el.firstNameField().type(generateNames());

        // Enter [Last Name]
        this.el.lastNameField().type(generateNames());

        // Click [I have read and accept the Services Agreement]
        this.el.servicesAgreementCheckbox().click();

        // Click [Agree]
        this.el.csaAgreeButton().click();

        // Click [Continue]
        this.el.continueButton().click();

        // Validate inbox
        cy.xpath('//span[contains(text(),"'+email+'")]').should('be.visible');
    }

} export default UserSignUp