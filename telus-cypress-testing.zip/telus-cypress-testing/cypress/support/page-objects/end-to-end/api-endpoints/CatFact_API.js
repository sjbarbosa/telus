const CatFactAPI = Cypress.env("CatFact");

const CatFactAPIEndPoints = {
    Fact: `${CatFactAPI}/fact`,
    Facts: `${CatFactAPI}/facts`,
    Breeds: `${CatFactAPI}/breeds`
};

export default CatFactAPIEndPoints;