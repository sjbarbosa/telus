import Languages from '../../../fixtures/Languages.json';

class UserProfile{
    continueButton = ".sc-eCApnc > .sui-rounded";
    usernameField = '//span[contains(text(),"Email")]/preceding-sibling::input';
    passwordField = '//span[contains(text(),"Password")]/preceding-sibling::input';
    profileIcon = '//button/div';
    myProfileButton = '//span[contains(text(),"My Profile")]';
    basicInfoEditContactInfoButton = '//div[2]/div[1]/div[2]/button';
    basicInfoEditLocationButton = '//div[1]/div[1]/div[2]/button';
    contactInfoPhoneNumberField = '//span[contains(text(),"Phone number")]/preceding-sibling::input';
    saveButton = '//button/span[contains(text(),"Save")]';
    locationStreetAddressField = '//span[contains(text(),"Street address (optional)")]/preceding-sibling::input';
    leftMenuLanguagesButton = '//a[contains(text(),"Languages")]';
    myLanguagesEditPrimaryLanguageButton = '//div[contains(@class, "primary-language")]/div[2]/div';
    myLanguageSearchPrimaryLanguageField = '//input[contains(@name, "language.id")]';
    addButton = '//button/span[contains(text(),"Add")]';
    myLanguageSearchOtherProficiencyField = '//input[contains(@name, "proficiency.id")]';
    signOutButton = '//span[contains(text(), "Sign Out")]';

    el = {
        continueButton: () => cy.get(this.continueButton, {timeout: 10000}),
        usernameField: () => cy.xpath(this.usernameField),
        passwordField: () => cy.xpath(this.passwordField),
        profileIcon: () => cy.xpath(this.profileIcon),
        myProfileButton: () => cy.xpath(this.myProfileButton),
        basicInfoEditContactInfoButton: () => cy.xpath(this.basicInfoEditContactInfoButton),
        basicInfoEditLocationButton: () => cy.xpath(this.basicInfoEditLocationButton),
        contactInfoPhoneNumberField: () => cy.xpath(this.contactInfoPhoneNumberField),
        saveButton: () => cy.xpath(this.saveButton),
        locationStreetAddressField: () => cy.xpath(this.locationStreetAddressField),
        leftMenuLanguagesButton: () => cy.xpath(this.leftMenuLanguagesButton),
        myLanguagesEditPrimaryLanguageButton: () => cy.get(this.myLanguagesEditPrimaryLanguageButton),
        myLanguageSearchPrimaryLanguageField: () => cy.get(this.myLanguageSearchPrimaryLanguageField),
        addButton: () => cy.get(this.addButton),
        myLanguageSearchOtherProficiencyField: () => cy.get(this.myLanguageSearchOtherProficiencyField),
        signOutButton: () => cy.get(this.signOutButton)
    }

    loginUser(username, password) {
        this.el.usernameField().type(username);
        this.el.continueButton().click();
        this.el.passwordField().type(password);
        this.el.continueButton().click();
    }

    navigateToMyProfile() {
        this.el.profileIcon().click();
        this.el.myProfileButton().click();
        this.el.profileIcon().click();
    }

    navigateToContactInfo() {
        this.el.basicInfoEditContactInfoButton().click();
    }

    updateContactInfo() {
        this.el.contactInfoPhoneNumberField({timeout: 10000}).scrollIntoView().should("be.visible").clear();
        this.el.contactInfoPhoneNumberField().type(Math.floor(100000000 + Math.random() * 900000000));
        this.el.saveButton().click({force: true});
    }

    navigateToLocation() {
        this.el.basicInfoEditLocationButton().click();
    }

    updateLocation() {
        const generate = () => Cypress._.random(0, 1e6)
        const id = generate()
        const streetAddress = `Street ${id}`
        this.el.locationStreetAddressField({timeout: 10000}).scrollIntoView().should("be.visible").clear();
        this.el.locationStreetAddressField().type(streetAddress);
        this.el.saveButton().click({force: true});
    }

    navigateToLanguages() {
        this.el.leftMenuLanguagesButton().click();
    }

    updatePrimaryLanguage() {
        this.el.myLanguagesEditPrimaryLanguageButton().click();
        this.el.myLanguageSearchPrimaryLanguageField().type(Languages.PRIMARYLANGUAGES[Math.floor(Math.random() * Languages.PRIMARYLANGUAGES.length)]).tab();
        this.el.saveButton().click({force: true});
    }

    addOtherLanguage() {
        this.el.addButton.click();
        this.el.myLanguageSearchPrimaryLanguageField().type(Languages.PRIMARYLANGUAGES[Math.floor(Math.random() * Languages.PRIMARYLANGUAGES.length)]).tab();
        this.el.myLanguageSearchOtherProficiencyField().type(Languages.PROFICIENCYLEVEL[Math.floor(Math.random() * Languages.PROFICIENCYLEVEL.length)]).tab();
        this.el.saveButton().click({force: true});
    }

    logoutUser() {
        this.el.profileIcon().scrollIntoView().should("be.visible").click({ force: true }, {timeout: 10000});
		this.el.signOutButton().should("be.visible").click({ force: true }, {timeout: 10000});
    }

} export default UserProfile